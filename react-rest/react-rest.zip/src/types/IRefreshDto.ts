export interface IRefreshDto {
    jwt: string,
    refreshToken: string
}
