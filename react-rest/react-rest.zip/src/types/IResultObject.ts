export interface IResultObject<TResponse> {
    errors?: string[]
    data?: TResponse
  }
