export interface ITag {
	id: string;
	name: string;
}
