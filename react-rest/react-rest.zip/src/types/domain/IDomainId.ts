export interface IDomainId {
	id: string
}
