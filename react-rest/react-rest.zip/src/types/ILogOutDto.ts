export interface ILogoutDto {
    tokenDeleteCount: number
}
