export interface IRegisterDto {
    jwt: string,
    refreshToken: string
}
