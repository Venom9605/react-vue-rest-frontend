export interface ILoginDto {
	jwt: string
	refreshToken: string
}
